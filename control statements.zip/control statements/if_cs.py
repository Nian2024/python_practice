def calculate_net_amount(product_code, order_amount):
    discount = 0

    # Determine the discount based on product code and order amount
    if product_code == 1:  # Battery-based toys
        if order_amount > 1000:
            discount = 0.10  # 10% discount
        elif order_amount > 100:
            discount = 0.05  # 5% discount
    elif product_code == 2:  # Key-based toys
        discount = 0  # No discount for key-based toys
    elif product_code == 3:  # Charging-based toys
        if order_amount > 500:
            discount = 0.10  # 10% discount

    # Calculate the net amount after discount
    net_amount = order_amount * (1 - discount)
    return net_amount

while True:
    # Read product code and order amount from user
    try:
        product_code = int(input("Enter the product code (1 for Battery-based, 2 for Key-based, 3 for Charging-based): "))
        order_amount = float(input("Enter the order amount: "))

        # Validate product code
        if product_code not in [1, 2, 3]:
            print("Invalid product code. Please enter 1, 2, or 3.")
            continue

        # Calculate the net amount
        net_amount = calculate_net_amount(product_code, order_amount)
        print(f"The net amount to pay after discount is: ${net_amount:.2f}")

    except ValueError:
        print("Invalid input. Please enter numerical values.")

    # Ask the user if they want to continue
    continue_choice = input("Do you want to continue? (yes/no): ").strip().lower()
    if continue_choice != 'yes':
        break
