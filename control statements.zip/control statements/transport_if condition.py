while True:
    # Input: Distance traveled
    distance = float(input("Enter the distance traveled (in km): "))

    # Initialize fare
    fare = 0

    # Calculate fare based on the distance
    if distance <= 50:
        fare = distance * 8  # 8 Rs/km for distance 1-50
    elif distance <= 100:
        fare = distance * 10  # 10 Rs/km for distance 51-100
    else:
        fare = distance * 12  # 12 Rs/km for distance more than 100

    # Display the fare
    print(f"The total fare for {distance} km is: Rs {fare:.2f}")

    # Ask if the user wants to continue
    continue_prompt = input("Do you want to calculate fare for another distance? (yes/no): ").strip().lower()
    if continue_prompt != 'yes':
        print("Thank you for using the fare calculator. Goodbye!")
        break
