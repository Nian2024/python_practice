# Sample dictionaries
dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}

# Concatenating the dictionaries
# Using the ** operator to unpack the dictionaries into a new dictionary
combined_dict = {**dic1, **dic2, **dic3}

# Printing the expected result
print("Expected Result:", combined_dict)


#Expected Result: {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
