# Input dictionary
input_dict = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}

# Printing header
print("key\tvalue")

# Iterating through the dictionary and printing key-value pairs where value is not None
for key, value in input_dict.items():
    if value is not None:
        print(f"{key}\t{value}")



'''Output
key	value
1	10
2	20
3	30
4	40
5	50
6	60'''
