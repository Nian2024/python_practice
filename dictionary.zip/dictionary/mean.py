# Given dictionary
test_dict = {"A": 6, "B": 9, "C": 5, "D": 7, "E": 4}

# Function to calculate the mean
def calculate_mean(data_dict):
    total = sum(data_dict.values())  # Sum of all values
    count = len(data_dict)            # Number of items in the dictionary
    mean = total / count               # Calculate the mean
    return mean

# Calling the function and printing the result
mean_value = calculate_mean(test_dict)
print("Output:", mean_value)


Output: 6.2
