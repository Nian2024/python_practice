# Input dictionary
input_dict = {1: 10, 2: 20, 3: None, 4: 40, 5: None, 6: 60}

# Creating a new dictionary without None values
filtered_dict = {k: v for k, v in input_dict.items() if v is not None}

# Printing the filtered dictionary
print("Output:", filtered_dict)
