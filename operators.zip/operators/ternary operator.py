# Declare two variables
a = 10
b = 20

# Use the ternary operator to find and print the largest variable
largest = a if a > b else b
print("The largest variable is:", largest)
