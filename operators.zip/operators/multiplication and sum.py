def multiply_and_sum(a, b):
    multiplication = a * b
    summation = a + b
    return multiplication, summation

# Example usage
num1 = 5
num2 = 3
multiplication, summation = multiply_and_sum(num1, num2)

print("Multiplication:", multiplication)
print("Sum:", summation)
