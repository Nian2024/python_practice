# Function to sum all items in a list
def sum_list(items):
    total = sum(items)  # Using the built-in sum() function
    return total

# Example list
numbers = [1, 2, 3, 4, 5]

# Calling the function and printing the result
result = sum_list(numbers)
print("The sum of all items in the list is:", result)
