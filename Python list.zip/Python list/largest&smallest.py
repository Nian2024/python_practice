# Function to find the largest and smallest numbers in a list
def find_largest_and_smallest(numbers):
    # Initialize largest and smallest with the first element of the list
    largest = smallest = numbers[0]

    # Iterate through the list to find the largest and smallest
    for num in numbers:
        if num > largest:
            largest = num
        if num < smallest:
            smallest = num

    return largest, smallest

# Example list
numbers = [5, 1, 8, 3, -2, 10, 0]

# Calling the function and printing the result
largest, smallest = find_largest_and_smallest(numbers)
print("The largest number is:", largest)
print("The smallest number is:", smallest)
