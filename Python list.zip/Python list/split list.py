# Function to split a list into two parts
def split_list(original_list, split_length):
    # Split the list into two parts
    first_part = original_list[:split_length]  # First part with specified length
    second_part = original_list[split_length:]  # Remaining part of the list
    return first_part, second_part

# Example list and split length
original_list = [1, 1, 2, 3, 4, 4, 5, 1]
split_length = 3

# Calling the function and printing the result
first_part, second_part = split_list(original_list, split_length)
print("Original list:", original_list)
print("Length of the first part of the list:", split_length)
print("Splitted the said list into two parts:", (first_part, second_part))
