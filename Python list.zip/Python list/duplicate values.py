# Function to find duplicate values in a list
def find_duplicates(numbers):
    duplicates = []  # List to store duplicates
    seen = set()     # Set to track seen numbers

    # Iterate through the list
    for num in numbers:
        # If the number is already in seen, it's a duplicate
        if num in seen:
            if num not in duplicates:
                duplicates.append(num)  # Add to duplicates if not already there
        else:
            seen.add(num)  # Add to seen if not already present

    return duplicates

# Example list
numbers = [1, 2, 3, 2, 4, 5, 3, 6, 1, 7, 5]

# Calling the function and printing the result
duplicates = find_duplicates(numbers)
print("Duplicate values in the list are:", duplicates)
