# Function to traverse a list in reverse order and print elements with original indices
def traverse_reverse(original_list):
    # Get the length of the list
    length = len(original_list)
    
    # Traverse the list in reverse order
    for index in range(length - 1, -1, -1):
        print(f"Index {index}: {original_list[index]}")

# Example list
original_list = ['red', 'green', 'white', 'black']

# Calling the function
print("Traverse the said list in reverse order:")
traverse_reverse(original_list)
