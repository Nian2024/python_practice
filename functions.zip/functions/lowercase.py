# Accept a name from the user
name = input("Please enter your name: ")

# Convert the name to lowercase
lowercase_name = name.lower()

# Display the name in lowercase
print("Your name in lowercase:", lowercase_name)
