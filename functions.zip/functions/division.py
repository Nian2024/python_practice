# Function to divide two numbers
def div(num1, num2):
    # Check for division by zero
    if num2 == 0:
        return "Error: Division by zero is not allowed."
    return num1 / num2

# Example usage
if __name__ == "__main__":
    # Input two numbers
    number1 = float(input("Enter the first number: "))
    number2 = float(input("Enter the second number: "))
    
    # Call the div function and display the result
    result = div(number1, number2)
    print(f"The result of dividing {number1} by {number2} is: {result}")
