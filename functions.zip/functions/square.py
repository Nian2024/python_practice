# Function to calculate the square of a number
def square(num):
    return num ** 2

# Example usage
if __name__ == "__main__":
    # Input a number
    number = float(input("Enter a number: "))
    
    # Call the square function and display the result
    result = square(number)
    print(f"The square of {number} is: {result}")
