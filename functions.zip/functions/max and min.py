import random

# Generate 5 random numbers
random_numbers = [random.randint(1, 100) for _ in range(5)]

# Display the random numbers
print("Random Numbers:", random_numbers)

# Find the maximum and minimum numbers
maximum = max(random_numbers)
minimum = min(random_numbers)

# Display the results
print("Maximum:", maximum)
print("Minimum:", minimum)
